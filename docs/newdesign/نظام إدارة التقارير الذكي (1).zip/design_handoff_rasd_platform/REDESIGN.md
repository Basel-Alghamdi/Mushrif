# رَصد — Redesign v2 (visual + navigation simplification)

**Status:** current. **Where this file and `SPEC.md` disagree, this file wins.**
**Functionality is unchanged.** Every field, action, endpoint, permission, and rule in `SPEC.md` and `EDITABILITY.md` still applies. This redesign changes how things look and how they're grouped, not what they do.

Reference prototype: `Rasd Platform.dc.html` (v2). The previous version is kept as `Rasd Platform v1.dc.html` for comparison only — do not build from it.

---

## 1. Navigation — 8 member pages → 3, 5 head pages → 4

### Member sidebar
| New page | Route | Contains, stacked top to bottom (same content as SPEC §3.3) |
|---|---|---|
| **اليوم** | `/cluster/today` (default after login) | Section 6 المهام (absence toggles, visits, plans) → Section 8 الاستيراد الذكي |
| **ملف العنقود** | `/cluster/file` | Section 1 البيانات الأولية → Section 2 مدارس العنقود |
| **المؤشرات** | `/cluster/indicators` | Section 3 التقويم المدرسي → 4 مدرستي → 5 الانضباط → 7 التطوير المهني |
| custom sections | `/cluster/s/:id` | unchanged — still listed below the three, still add/rename/delete |

- **Badge:** only `اليوم` carries one — count of schools still missing absence today (hidden at 0). No status dots on any nav item.
- The daily job (mark absence, upload visit brief + documents) is now the first thing a member lands on.

### Head sidebar
| New page | Contains |
|---|---|
| **لوحة النطاق** (badge = members not yet submitted) | SPEC View A نظرة النطاق **+** View B متابعة الإرسال, stacked on one page |
| **أعضاء الفريق** `٢٥` | View C (unchanged) → View D profile (unchanged) |
| **المساعد الذكي** | View E (unchanged) |
| **التقرير المجمّع** | View F (unchanged) |

## 2. Page headers
- **Removed** all ordinal eyebrows (`القسم الأول` … `القسم الثامن`, `متابعة يومية`). They referenced the old 8-page structure.
- Each page has **one h1** (24px/600). Every section merged below it gets an **h2** (18px/600, letter-spacing −.01em).
- Merged sections are separated by a **38px gap** (main is `flex column; gap:38px`).
- Login stat `٧ أقسام في ملف العنقود` → `٦ مدارس لكل عنقود`.
- Sidebar completion label: `اكتمال أقسام الملف` (dropped "السبعة").

## 3. Color — one accent, one alert
Replaces SPEC §1.3 status/tier usage. Tokens themselves unchanged.

| Meaning | Before | Now |
|---|---|---|
| Good / done / on-target number | green `#067647` | ink `#000000de` |
| OK / mid number | teal | ink `#000000de` |
| Warning (متأخرة, needs review) | amber `#b45309` | dark amber `#92400e` — **text only, sparing** |
| Bad / below 75 / missing / لا يوجد | red | red `#dc2626` (unchanged) |
| Progress bars | 4-colour scale | teal `#009688` ≥75, red `#dc2626` <75 |
| Tier distribution chart | 4 hues | single teal ramp: تميز `#007970` · تقدم `#009688` · انطلاق `#5cbfb4` · تهيئة `#a2e0d8` |
| Absence toggle | green/red tint | done `#e1f5f2`/`#007970` · not done `#dc262614`/`#dc2626` |

**Rule:** `#067647` and `#b45309` no longer appear anywhere. Red is the only colour that means "look here".

## 4. Pills — outline, not tinted
Replaces SPEC §1.3 "Tier pill = 8% tint".
```
base:    padding 4px 10px · radius 99px · 11px · weight 500
         display:inline-block · width:fit-content · justify-self:start   ← never stretch in a grid cell
neutral: bg #fff · border 1px #00000026 · text #00000099
alert:   bg #fff · border 1px #dc262633 · text #dc2626
warning: bg #fff · border 1px #f59e0b4d · text #92400e
accent:  bg #fff · border 1px #00968840 · text #007970
```
Tier pills are **neutral** for تميز / تقدم / انطلاق and **alert** for تهيئة only.
Build one helper `pill(tone)`. **Never build colours by appending alpha to a hex string** (`${c}14`) — it breaks on 8-digit hex.

## 5. Type scale — 6 steps only
Replaces SPEC §1.2 sizes. Every size snaps to: **11 · 12 · 13 · 15 · 18 · 24 px.**
Meta 11 · body/labels 12–13 · card titles 15 · h2 18 · h1 & big numbers 24.

## 6. Radius — 2 steps only
Replaces SPEC §1.4. **8px** (inputs, small buttons, tiles) · **12px** (cards, panels, large buttons) · 99px pills/avatars.

## 7. Surfaces & borders
- **No dark in-app panels.** Former `#001d1a` cards are now white cards with `1px #00000014` border; their accent text is `#007970`, body `#00000099`. The login brand panel is the only dark surface left.
- **No glow** on primary buttons (removed `0 2px 10px rgba(0,150,136,.24)`).
- Add-buttons / add-tiles: `1px solid #00000014` (was 1.5px dashed teal). Dashed `1px #00000021` only for rename inputs and dropzones. Add-button bg `#fff`, text `#007970`.
- Buttons formerly on dark panels: solid `#009688` / white text.

## 8. Label-edit mode
- **Default is OFF** (was ON). The first screen shows values, not rename boxes.
- The `تخصيص حقول المدرسة` panel (show/hide school fields) now appears **only in label-edit mode**.
- Unchanged: `+ إضافة …`, `×`, and value inputs are **always visible** in both modes (EDITABILITY §3).

## 9. Responsive — two breakpoints
Extends SPEC §1.9.
- **≤1150px:** the two-column splits (schools list+detail, leadership rows, profile timeline, report split) and the profile-fields grid collapse to one column; span-2 fields reset to span 1; sticky school list becomes static.
- **≤900px:** everything in SPEC §1.9 (drawer sidebar, burger, header collapse, fixed dropdowns). Additionally the **role pill is hidden** and the member's field-view button becomes a **36px icon-only** square.

## 10. Build checklist for the redesign
- [ ] Member lands on **اليوم**; sidebar shows exactly 3 pages + custom sections
- [ ] Head sidebar shows exactly 4 pages; لوحة النطاق contains both KPIs and the 25-member submission board
- [ ] Search codebase for `#067647`, `#b45309`, `القسم الأول` → zero hits
- [ ] No pill stretches to its grid cell width
- [ ] Only 6 font sizes and 2 radii in use (plus 99px)
- [ ] Label-edit off on first load; add/delete visible anyway
- [ ] No horizontal overflow at 1024, 900, 768, 390px (except table scroll wrappers)
- [ ] Every EDITABILITY.md acceptance item still passes — nothing functional regressed
